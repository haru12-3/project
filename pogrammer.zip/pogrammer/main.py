import datetime
import json
import os
import threading
import time
import random
from flask import Flask, request, jsonify, make_response, render_template
from neo4j_handler import Neo4j_Handle
from clac.jieba_tools import MatchPlace

graph_handler = Neo4j_Handle("http://localhost:7474", "neo4j", "changgong")
graph = graph_handler.graph

city_lis = graph.run("MATCH (n:City) RETURN n").data()
city_keywords  = [x['n']['name'] for x in city_lis]
match_place = MatchPlace(city_keywords)

app = Flask(__name__)

@app.route("/", methods=['GET', 'POST'])
def index():
    rand_int = random.randint(0, 10000)
    user_single = f"{time.time() * 1000 * 1000}_{rand_int}"
    return render_template("index.html", **{
        "user_single": user_single,
    })

def neo4j_cmd_other_one(user_id): #1.根据用户的历史行为（搜索和兴趣点）生成推荐 2.使用PageRank算法在图数据库中生成推荐

    cypher = """
        MATCH (u:User {id: $user_id})-[r]->(d:Detail)
        WITH u, r, d
        ORDER BY r.lastUpdated DESC
        LIMIT 1
        RETURN u, d
    """
    results = graph.run(cypher, user_id=user_id).data()
    if not results:
        return []
    city_obj = dict(results[0]["d"])
    city_name = city_obj["province"]
    big_kind = city_obj["big_kind"]
    print("resultsresultsresults:: ", city_name)

    model_name = "detailsGraph"
    cypher = f"""
        CALL gds.graph.exists('{model_name}') YIELD exists
        WHERE exists
        CALL gds.graph.drop('{model_name}') YIELD graphName
        RETURN 'Dropped graph ' + graphName    
    """

    graph_handler.graph.run(cypher)

    query = """
        MATCH (u:User {id: $user_id})-[:SEARCHED_CITY]->(c:City)
        WITH u, c
        ORDER BY c.lastSearched DESC
        LIMIT 1

        // 找到与该城市相关的BigKind为"休闲娱乐"的Detail节点，并创建一个虚拟图
        CALL gds.graph.project(
          'detailsGraph',
          {
            Detail: {
              label: 'Detail'
            }
          },
          {
            HAS_DETAIL: {
              type: 'HAS_SMALL_KIND',
              orientation: 'UNDIRECTED'
            }
          }
        )
        YIELD graphName, nodeCount, relationshipCount

        // 在虚拟图上运行PageRank算法
        CALL gds.pageRank.stream('detailsGraph', {maxIterations: 20, dampingFactor: 0.85})
        YIELD nodeId, score


        // 将结果与原始Detail节点匹配
        WITH u, gds.util.asNode(nodeId) AS d, score
        // ORDER BY score DESC
        // LIMIT 5
        WITH u, collect(d) as details, score
        WITH u, apoc.coll.shuffle(details) as shuffledDetails, score
        //WITH u, shuffledDetails[..5] as topDetails, score
        //UNWIND topDetails as d
        UNWIND shuffledDetails as d
        WITH u, d, score
        WHERE d.province = $city_name AND d.big_kind = $big_kind

        // 将结果与用户的SEARCHED关系合并
        //MERGE (u)-[r:SEARCHED]->(d)
        //ON CREATE SET r.count = 1, r.timestamp = datetime()
        //ON MATCH SET r.count = r.count + 1, r.timestamp = datetime()
        RETURN d, score
    """
    results = graph.run(query, user_id=user_id, city_name=city_name, big_kind=big_kind).data()[:5]
    return results, SEACH_TYPE_DETAILS

def neo4j_cmd_other_two(user_id):
    cypher = """
        MATCH (u:User {id: $user_id})-[r:SEARCHED]->(d:Detail)
        WITH u, r, d
        ORDER BY r.lastUpdated DESC
        LIMIT 1
        RETURN u, d
    """
    results = graph.run(cypher, user_id=user_id).data()
    if not results:
        return []

    city_obj = dict(results[0]["d"])
    city_name = city_obj["province"]
    big_kind = city_obj["big_kind"]
    small_kind = city_obj["small_kind"]

    print("resultsresultsresults:: ", city_name, big_kind, small_kind)

    query = """
        MATCH (c:City {name: $city_name})-[:HAS_BIG_KIND]-(b:BigKind {name: $big_kind})-[:HAS_SMALL_KIND]-(s:SmallKind {name: $small_kind})-[:HAS_DETAIL]-(d:Detail)
        // WHERE NOT (u)-[]-(d)
        WHERE d.province = $city_name AND d.big_kind = $big_kind AND d.small_kind = $small_kind
        WITH c, collect(d) as details
        WITH c, apoc.coll.shuffle(details) as shuffledDetails
        WITH c, shuffledDetails[..5] as topDetails
        UNWIND topDetails as d
        RETURN d
        """

    results = graph.run(query, user_id=user_id, city_name=city_name, big_kind=big_kind, small_kind=small_kind).data()[:5]
    return results, SEACH_TYPE_NOTES

def neo4j_cmd_other_details(user_id):  #动态调整推荐结果，基于用户的最近搜索或兴趣点
    # 判断具体detail访问时间和城市查看时间
    cypher = """
        MATCH (u:User {id: $user_id})-[r: SEARCHED]-()
        WITH u, r
        ORDER BY r.timestamp DESC 
        LIMIT 1
        RETURN u, r
    """
    res_searched_city = graph.run(cypher, user_id=user_id).data()

    cypher = """
        MATCH (u:User {id: $user_id})-[r: INTERESTED_IN]-()
        WITH u, r
        ORDER BY r.lastUpdated DESC
        LIMIT 1
        RETURN u, r
        """
    res_interested_in = graph.run(cypher, user_id=user_id).data()

    res_searched_time = res_searched_city[0]["r"]["timestamp"] if res_searched_city else "0"
    res_interested_time = res_interested_in[0]["r"]["lastUpdated"] if res_interested_in else "0"
    # City jingdian  res_interested_time 2024-05-20T06:08:21.931Z
    print("TIME: ", res_searched_time, res_interested_time)

    if res_interested_time >= res_searched_time:
        return neo4j_cmd_other_one(user_id)
    else:
        return neo4j_cmd_other_two(user_id)

def neo4j_cmd_search_city_category(user_id, city_name, big_kind_name):#记录用户的搜索行为和兴趣点

    query = """
    MATCH (c:City {name: $city_name})-[:HAS_BIG_KIND]-(b:BigKind {name: $big_kind_name})-[:HAS_SMALL_KIND]-(s:SmallKind)-[:HAS_DETAIL]-(d:Detail {province: $city_name})
    WITH c, collect(d) as details
    WITH c, apoc.coll.shuffle(details) as shuffledDetails
    WITH c, shuffledDetails[..5] as topDetails
    UNWIND topDetails as d
    MERGE (u:User {id: $user_id})-[sc:SEARCHED_CITY]->(c)
    ON CREATE SET u.searchedCount = 1, u.lastSearched = datetime()
    ON MATCH SET u.searchedCount = u.searchedCount + 1, u.lastSearched = datetime()
    MERGE (u)-[r:INTERESTED_IN]->(d)
    ON CREATE SET r.count = 1, r.lastUpdated = datetime()
    ON MATCH SET r.count = r.count + 1, r.lastUpdated = datetime()
    RETURN d
    """
    results = graph.run(query, user_id=user_id, city_name=city_name, big_kind_name=big_kind_name).data()

    return results

def neo4j_cmd_search_note(user_id, search_name_fragment=""):
    cypher = """
        MATCH (u:User {id: $user_id})-[r]->(d:Detail)
        WITH u, r, d
        ORDER BY r.lastUpdated DESC
        LIMIT 1
        RETURN u, d
    """
    results = graph.run(cypher, user_id=user_id).data()

    try:
        city_obj = dict(results[0]["d"])
        city_name = city_obj["province"]
        big_kind = city_obj["big_kind"]
    except Exception:
        city_name = ""
        big_kind = ""

    results = []
    if city_name:
        query = """
        MATCH (d:Detail)
        WHERE d.name CONTAINS $search_name AND d.province = $city_name
        WITH d
        LIMIT 5  
        MERGE (u:User {id: $user_id})
        MERGE (u)-[r:SEARCHED]->(d)
        ON CREATE SET r.count = 1, r.timestamp = datetime()
        ON MATCH SET r.count = r.count + 1, r.timestamp = datetime()
        RETURN DISTINCT d
        """
        results = graph.run(query, search_name=search_name_fragment, city_name=city_name, user_id=user_id).data()

    if not results:
        query = """
        MATCH (d:Detail)
        WHERE d.name CONTAINS $search_name
        WITH d
        LIMIT 5  
        MERGE (u:User {id: $user_id})
        MERGE (u)-[r:SEARCHED]->(d)
        ON CREATE SET r.count = 1, r.timestamp = datetime()
        ON MATCH SET r.count = r.count + 1, r.timestamp = datetime()
        RETURN DISTINCT d
        """

        results = graph.run(query, search_name=search_name_fragment, user_id=user_id).data()


    # query = """
    # MATCH (d:Detail)
    # WHERE d.name CONTAINS $search_name
    # WITH d
    # LIMIT 5
    # RETURN d
    # """
    # results = graph.run(query, search_name=search_name_fragment)

    return results




SEACH_TYPE_DETAILS = "details"
SEACH_TYPE_NOTES = "notes"

@app.route("/chat", methods=["GET", "POST"])
def chat():
    print("request.json: ", request.json)
    user_single = request.json.get("user_single", "")
    content = request.json.get("content", "")

    for cd in ["还有哪些", "其他推荐", "其他", "还有", "其他的", "其他的有", "其他的有哪些"]:
        if cd in content:
            results, search_type = neo4j_cmd_other_details(user_single)
            results = [dict(x["d"]) for x in results]
            return jsonify({
                "code": 200,
                "search_type": search_type,
                "results": results,
            })

    city, category, specific_place = match_place.identify_category_and_city(content)
    print(f"问题: \"{content}\"")
    search_type = ""
    if city and category:
        search_type = SEACH_TYPE_DETAILS
        print(f"识别地点: {city}")
        print(f"识别类别: {category}")
    elif specific_place:
        search_type = SEACH_TYPE_NOTES
        print(f"识别具体地点: {specific_place}")
    else:
        print(f"无法识别的问题格式")

    results = []
    if search_type == SEACH_TYPE_DETAILS:
        results = neo4j_cmd_search_city_category(user_single, city, category)
        results = [dict(x["d"]) for x in results]
    elif search_type == SEACH_TYPE_NOTES:
        results = neo4j_cmd_search_note(user_single, specific_place)
        results = [dict(x["d"]) for x in results]

    print("RESULTS: ", results)

    return jsonify({
        "code": 200,
        "search_type": search_type,
        "results": results,
    })


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=True)