import jieba


jieba.load_userdict('data_txt/userdict.txt')

category_keywords = {
    '休闲娱乐': ['休闲', '娱乐', '玩'],
    '景点': ['景点', '旅游', '游览', '参观'],
    '购物': ['购物', '逛街', '商场', "购物中心", "商店"],
    '美食': ['美食', '吃', '餐厅', '美味'],
    '酒店': ['住宿', '酒店', '宾馆', '旅馆'],
}

# 地点查询和列表查询的关键词
address_keywords = ['地址', '在哪','在哪里', '怎么走', '如何到达', '位置', "详情", "具体"]
list_keywords = ['都有', '都', "有", '都有哪些', '有哪些', '列出', '列表', "中心"]

stopwords = set()
with open('data_txt/cn_stopwords.txt', 'r', encoding='utf-8') as f:
    for line in f:
        if line.strip():
            stopwords.add(line.strip())

class MatchPlace:
    def __init__(self, city_keywords):
        self.city_keywords = city_keywords

    def extract_keywords(self, question):
        words = jieba.cut(question)
        extracted_keywords = list(words)
        filtered_words = [word for word in extracted_keywords if word not in stopwords]
        return filtered_words

    def identify_category_and_city(self, question):
        extracted_keywords = self.extract_keywords(question)
        city, category, specific_place = None, None, None

        # 检测是否是地址或方向查询
        if any(keyword in question for keyword in address_keywords):
            specific_place = next((word for word in extracted_keywords if word not in address_keywords), None)
            return city, category, specific_place

        # 检测是否是列表查询
        if any(keyword in question for keyword in list_keywords):
            city = next((word for word in extracted_keywords if word in self.city_keywords), None)
            category = next((cat for cat, keywords in category_keywords.items() if set(keywords) & set(extracted_keywords)), None)
            return city, category, specific_place

        # 普通类别和城市识别
        for word in extracted_keywords:
            if word in self.city_keywords:
                city = word
            for cat, keywords in category_keywords.items():
                if word in keywords:
                    category = cat
                    break

        return city, category, specific_place

    def identify_category_and_city2(self, question):
        extracted_keywords = self.extract_keywords(question)
        category = None
        city = None
        for word in extracted_keywords:
            if word in self.city_keywords:
                city = word
            for cat, keywords in category_keywords.items():
                if word in keywords:
                    category = cat

        # 从问题中提取具体的地名或场所名
        specific_place = None
        if category and not city:
            # 如果category存在，但city不存在，那么问题可能是询问具体地方
            for word in extracted_keywords:
                if word not in category_keywords[category]:
                    specific_place = word

        return city, category, specific_place

    def segment(self, text):
        words = jieba.cut(text)
        filtered_words = [word for word in words if word not in stopwords]
        return filtered_words